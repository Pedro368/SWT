from django.shortcuts import render
from app.models import Project

def index(request):
    app = Project.objects.all()
    context = {
      'app' : app
    }
    return render(request, 'index.html', context)

def home(request):
    app = Project.objects.all()
    context = {
      'app' : app
    }
    return render(request, 'home.html', context)
