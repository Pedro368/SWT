package application;

import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;

public class ProductosController {

	    @FXML
	    private TableView<Productos> ProductosTable;
	    @FXML
	    private TableColumn<Productos, String> DescripcionColumn;
	    @FXML
	    private TableColumn<Productos, Integer> StockColumn;

	    @FXML
	    private Label DescripcionLabel;
	    @FXML
	    private Label StockLabel;
	    @FXML
	    private Label DescripcionFuturaLabel;
	    @FXML
	    private Label PrecioLabel;
	    @FXML
	    private Label StockFuturoLabel;
	    @FXML
	    private Label FechaDeFabricacionLabel;

	    private Main mainApp;

	    public ProductosController() {
	    }

	    @FXML
	    private void initialize() {
	        DescripcionColumn.setCellValueFactory(cellData -> cellData.getValue().DescripcionProperty());
	        StockColumn.setCellValueFactory(cellData -> cellData.getValue().StockProperty());		
	    }
	    		
	    public void setMainApp(Main mainApp) {
	        this.mainApp = mainApp;

	        ProductosTable.setItems(mainApp.getProductosData());
	    }
	}
}
