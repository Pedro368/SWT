package application;
	
import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.stage.Stage;
import javafx.scene.Scene;
import javafx.scene.layout.VBox;
import javafx.fxml.FXMLLoader;


public class Main extends Application {
	private ObservableList<Productos> ProductosData = FXCollections.observableArrayList();

    public void MainApp() {
        ProductosData.add(new Productos("Condones", 12));
        ProductosData.add(new Productos("Lentejas", 2));
        ProductosData.add(new Productos("Altramuces", 4));
        ProductosData.add(new Productos("Televisiones", 2));
        ProductosData.add(new Productos("Hornos", 4));
        ProductosData.add(new Productos("Coches", 2));
        ProductosData.add(new Productos("Ratones", 1));
        ProductosData.add(new Productos("Ciervo", 5));
        ProductosData.add(new Productos("Altavoces", 14));
    }
  
    public ObservableList<Productos> getProductosData() {
        return ProductosData;
    }
    @Override
	public void start(Stage primaryStage) {
		try {
			VBox root = (VBox)FXMLLoader.load(getClass().getResource("Sample.fxml"));
			Scene scene = new Scene(root,400,400);
			scene.getStylesheets().add(getClass().getResource("application.css").toExternalForm());
			primaryStage.setScene(scene);
			primaryStage.show();
		} catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	public static void main(String[] args) {
		launch(args);
	}
}
