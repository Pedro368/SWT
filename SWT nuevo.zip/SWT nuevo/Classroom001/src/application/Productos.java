package application;

import javafx.beans.property.DoubleProperty;
import javafx.beans.property.IntegerProperty;
import javafx.beans.property.ObjectProperty;
import javafx.beans.property.SimpleDoubleProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleObjectProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;
import java.time.LocalDate;

public class Productos {
	
	    private final StringProperty Descripcion;
	    private final IntegerProperty Stock;
	    private final StringProperty DescripcionFutura;
	    private final DoubleProperty Precio;
	    private final IntegerProperty StockFuturo;
	    private final ObjectProperty<LocalDate> FechaDeFabricacion;
	    
	    public Productos() {
	        this(null, 0);
	    }
	  
	    public Productos(String Descripcion, Integer Stock) {
	        this.Descripcion = new SimpleStringProperty(Descripcion);
	        this.Stock = new SimpleIntegerProperty();
	        
	        // Some initial dummy data, just for convenient testing.
	        this.DescripcionFutura = new SimpleStringProperty();
	        this.Precio = new SimpleDoubleProperty();
	        this.StockFuturo = new SimpleIntegerProperty();
	        this.FechaDeFabricacion = new SimpleObjectProperty<LocalDate>(LocalDate.of(1999, 2, 21));
	    }
	    
	    public String getDescripcion() {
	        return Descripcion.get();
	    }

	    public void setDescripcion(String Descripcion) {
	        this.Descripcion.set(Descripcion);
	    }
	    
	    public StringProperty DescripcionProperty() {
	        return Descripcion;
	    }

	    public Integer getStock() {
	        return Stock.get();
	    }

	    public void setStock(Integer Stock) {
	        this.Stock.set(Stock);
	    }
	    
	    public IntegerProperty StockProperty() {
	        return Stock;
	    }

	    public String getDescripcionFutura() {
	        return DescripcionFutura.get();
	    }

	    public void setDescripcionFutura(String DescripcionFutura) {
	        this.DescripcionFutura.set(DescripcionFutura);
	    }
	    
	    public StringProperty DescripcionFuturaProperty() {
	        return DescripcionFutura;
	    }

	    public double getPrecio() {
	        return Precio.get();
	    }

	    public void setPrecio(int Precio) {
	        this.Precio.set(Precio);
	    }
	    
	    public DoubleProperty PrecioProperty() {
	        return Precio;
	    }

	    public Integer getStockFuturo() {
	        return StockFuturo.get();
	    }

	    public void setStockFuturo(Integer StockFuturo) {
	        this.StockFuturo.set(StockFuturo);
	    }
	    
	    public IntegerProperty StockFuturoProperty() {
	        return StockFuturo;
	    }

	    public LocalDate getFechaDeFabricacion() {
	        return FechaDeFabricacion.get();
	    }

	    public void setFechaDeFabricacion(LocalDate FechaDeFabricacion) {
	        this.FechaDeFabricacion.set(FechaDeFabricacion);
	    }
	    
	    public ObjectProperty<LocalDate> FechaDeFabricacionProperty() {
	        return FechaDeFabricacion;
	    }
	}

